var mouse = {
    upX: 0,
    upY: 0,
    downX: 0,
    downY: 0
};

function mouseInfo(socket) {

}
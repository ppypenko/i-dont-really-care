   function roundToTenth(num) {
        return (Math.round(num * 10)) / 10
    }